<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/2
 * Time: 13:57
 */

namespace app\demo\model;

use think\Model;

class demoModel extends Model
{
    protected $pk = 'id';

    protected $table = 'yc_demo';

    protected $field = true;


}
